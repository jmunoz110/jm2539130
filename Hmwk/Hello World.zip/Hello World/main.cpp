// Jonathan Munoz

// Preprocessor Directive
#include <iostream>
using namespace std;

// Program
int main()
{
    // Display sentence on monitor
    cout << "Hello, World!";
    
    // End the program
    return 0;
}