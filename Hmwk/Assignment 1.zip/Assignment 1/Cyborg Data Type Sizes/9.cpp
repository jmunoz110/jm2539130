// Jonathan Munoz
// Cyborg Data Type Sizes

#include <iostream>
using namespace std;

int main()
{
    cout << "The char data type uses " << sizeof(char) << " byte." << endl;
    cout << "The int data type uses " << sizeof(int) << " bytes." << endl;
    cout << "The float data type uses " << sizeof(float) << " bytes" << endl;
    cout << "The double data type uses " << sizeof(double) << " bytes" << endl;
    
    return 0;
}