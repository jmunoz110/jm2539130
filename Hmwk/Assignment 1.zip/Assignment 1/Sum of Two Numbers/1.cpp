/* Jonathan Munoz
Sum of Two Numbers
*/ 
#include <iostream>
using namespace std;

int main()
{
    // The numbers 50 and 100 stored in variables
    short num1 = 50, num2 = 100, total;
    
    // The sum stored in a variable
    total = num1 + num2;
    
    // The sum displayed
    cout << "The sum of 50 and 100 is " << total;
    
    return 0;
}